import { expect } from 'chai'

describe('Simple test', () => {

    it('1 + 1 = 2', () => {
        expect(1 + 1).to.eql(2)
    })
})
